var TsdbDataClient = require('./node_modules/bce-sdk-js/src/tsdb_data_client'); 
function flattenTsdbResult(body) {
	var newObj = {};
	body.flatResults = newObj;
	
	// total count
	newObj.count = body.results.length;
	
	for (i = 0; i < body.results.length; i++) {
		var resulti = {};
		var keyi = "result" + i;
		newObj[keyi] = resulti;
		
		resulti.metric = body.results[i].metric;
		resulti.field = body.results[i].field;
		resulti.rawCount = body.results[i].rawCount;
		
		resulti.groupCount = body.results[i].groups.length;
		var groups = {};
		resulti.groups = groups;
		for (j = 0; j < body.results[i].groups.length; j++) {
			var groupi = {};
			var groupKey = "group" + j;
			groups[groupKey] = groupi;
			
			groupi.valueCount = body.results[i].groups[j].values.length;
			var values = {};
			groupi.values = values;
			for (k = 0; k < body.results[i].groups[j].values.length; k++) {
				var valuek = {};
				var valueKey = "value" + k;
				values[valueKey] = valuek;
				
				if (body.results[i].groups[j].values[k].length >= 1) {
					valuek.ts = body.results[i].groups[j].values[k][0];
				}
				if (body.results[i].groups[j].values[k].length >= 2) {
					valuek.val = body.results[i].groups[j].values[k][1];
				}
				if (body.results[i].groups[j].values[k].length >= 3) {
					valuek.val2 = body.results[i].groups[j].values[k][2];
				}
				if (body.results[i].groups[j].values[k].length >= 4) {
					valuek.val3 = body.results[i].groups[j].values[k][3];
				}
				if (body.results[i].groups[j].values[k].length >= 5) {
					valuek.val4 = body.results[i].groups[j].values[k][4];
				}
				if (body.results[i].groups[j].values[k].length >= 6) {
					valuek.val5 = body.results[i].groups[j].values[k][5];
				}
				if (body.results[i].groups[j].values[k].length >= 7) {
					valuek.val6 = body.results[i].groups[j].values[k][6];
				}
				if (body.results[i].groups[j].values[k].length >= 8) {
					valuek.val7 = body.results[i].groups[j].values[k][7];
				}
				if (body.results[i].groups[j].values[k].length >= 9) {
					valuek.val8 = body.results[i].groups[j].values[k][8];
				}
				if (body.results[i].groups[j].values[k].length >= 10) {
					valuek.val9 = body.results[i].groups[j].values[k][9];
				}
				if (body.results[i].groups[j].values[k].length >= 11) {
					valuek.val10 = body.results[i].groups[j].values[k][10];
				}
			}
		}
	}
	
	return body;
}

exports.handler = (event, context, callback) => {

	const config = {
		endpoint: "http://<your_tsdb_name>.tsdb.iot.<bj or gz>.baidubce.com",                 
		credentials: {
			ak: "<your access key>",  
			sk: "<your secret key>" 
		}
	};
	let client = new TsdbDataClient(config);
	client.getDatapoints(event)
    .then(response => callback(null, flattenTsdbResult(response.body))).catch(callback);
};

// a sample event:
//[
//    {
//        "metric": "RuleEngineProcess",
//        "filters": {
//            "start": "2 minute ago"
//        },
//        "aggregators": [
//            {
//                "name": "Sum",
//                "sampling": "3 minutes"
//            }
//        ]
//    }
//]